const DOCK_FOLDER_NAME = "Vertical-bookmark-list";

async function getOrCreateDockFolder() {
  const tree = await chrome.bookmarks.getTree();
  let dockFolder = findFolder(tree, DOCK_FOLDER_NAME);
  
  if (!dockFolder) {
    const parent = tree[0].children.find(c => c.id === '2') || tree[0]; 
    dockFolder = await chrome.bookmarks.create({
      parentId: parent.id,
      title: DOCK_FOLDER_NAME
    });
  }
  return dockFolder;
}

async function getDockBookmarks() {
  const dockFolder = await getOrCreateDockFolder();
  const children = await chrome.bookmarks.getChildren(dockFolder.id);
  
  const syncStorage = await chrome.storage.sync.get(['customIcons', 'settingsIcon', 'showSettings']);
  const localStorage = await chrome.storage.local.get(['faviconCache']);
  
  const customIcons = syncStorage.customIcons || {};
  const faviconCache = localStorage.faviconCache || {};
  
  const settingsIcon = (syncStorage.settingsIcon && syncStorage.settingsIcon.trim() !== '') 
    ? syncStorage.settingsIcon 
    : chrome.runtime.getURL("gears.png");

  const itemsToCache = [];

  const processNode = async (bm) => {
    let iconUrl = '';
    
    if (customIcons[bm.id]) {
      iconUrl = customIcons[bm.id];
    } else if (faviconCache[bm.id]) {
      iconUrl = faviconCache[bm.id];
    } else if (bm.url) {
      if (!bm.url.startsWith('data:')) {
        try {
            iconUrl = `https://www.google.com/s2/favicons?domain=${new URL(bm.url).hostname}&sz=64`;
            itemsToCache.push({ id: bm.id, url: iconUrl });
        } catch(e) { iconUrl = ""; }
      } else {
        iconUrl = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzQ0Y2NmZiI+PHBhdGggZD0iTTEwIDRINmMtMS4xIDAtMiAuOS0yIDJ2MTJjMCAxLjEuOSAyIDIgMmgxMmMxLjEgMCAyLS45IDItMlY4YzAtMS4xLS45LTItMi0yaC04bC0yLTJ6Ii8+PC9zdmc+";
      }
    } else {
      iconUrl = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzQ0Y2NmZiI+PHBhdGggZD0iTTEwIDRINmMtMS4xIDAtMiAuOS0yIDJ2MTJjMCAxLjEuOSAyIDIgMmgxMmMxLjEgMCAyLS45IDItMlY4YzAtMS4xLS45LTItMi0yaC04bC0yLTJ6Ii8+PC9zdmc+"; 
    }

    const item = { 
      id: bm.id, 
      title: bm.title, 
      url: bm.url, 
      iconUrl: iconUrl,
      index: bm.index,
      parentId: bm.parentId
    };

    if (!bm.url) {
      const subChildren = await chrome.bookmarks.getChildren(bm.id);
      item.children = await Promise.all(subChildren.map(child => processNode(child)));
    }

    return item;
  };

  const bookmarks = await Promise.all(children.map(processNode));

  if (itemsToCache.length > 0) {
    cacheMissingIcons(itemsToCache);
  }

  if (syncStorage.showSettings !== false) {
    bookmarks.push({ title: "-", id: "spacer_settings" });
    bookmarks.push({
      id: "dock_settings_item",
      title: "Settings",
      url: "#settings",
      iconUrl: settingsIcon
    });
  }

  return bookmarks;
}

async function cacheMissingIcons(items) {
  const storage = await chrome.storage.local.get(['faviconCache']);
  const cache = storage.faviconCache || {};

  for (const item of items) {
    try {
      const response = await fetch(item.url);
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        cache[item.id] = reader.result;
        chrome.storage.local.set({ faviconCache: cache });
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.log(`Failed to cache icon for ${item.id}`, err);
    }
  }
}

function findFolder(nodes, name) {
  for (const node of nodes) {
    if (node.title === name && !node.url) return node;
    if (node.children) {
      const found = findFolder(node.children, name);
      if (found) return found;
    }
  }
  return null;
}

function broadcastRefresh() {
  getDockBookmarks().then(bookmarks => {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "refresh_dock", data: bookmarks })
          .catch(() => {}); 
      }
    });
  });
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "toggle_dock") {
    const bookmarks = await getDockBookmarks();
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggle_dock", data: bookmarks }, () => {
             if (chrome.runtime.lastError) {}
        });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "get_bookmarks_for_mouse") {
    getDockBookmarks().then(bookmarks => {
      sendResponse({ data: bookmarks });
    });
    return true; 
  }
  
  if (request.action === "request_refresh") {
    broadcastRefresh();
  }
  
  if (request.action === "add_current_tab") {
    chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
        const tab = tabs[0];
        if (tab && tab.url) {
            const dockFolder = await getOrCreateDockFolder();
            await chrome.bookmarks.create({
                parentId: dockFolder.id,
                title: tab.title,
                url: tab.url
            });
            broadcastRefresh();
        }
    });
  }

  if (request.action === "open_settings") { chrome.runtime.openOptionsPage(); }
  if (request.action === "open_new_window") { chrome.windows.create({ url: request.url }); }
  if (request.action === "open_incognito") { chrome.windows.create({ url: request.url, incognito: true }); }
  if (request.action === "rename_bookmark") { chrome.bookmarks.update(request.id, { title: request.title }, () => broadcastRefresh()); }
  if (request.action === "delete_bookmark") { chrome.bookmarks.remove(request.id, () => broadcastRefresh()); }
  if (request.action === "update_icon") {
    chrome.storage.sync.get(['customIcons'], (result) => {
      const icons = result.customIcons || {};
      if (request.url) { icons[request.id] = request.url; } 
      else { delete icons[request.id]; }
      chrome.storage.sync.set({ customIcons: icons }, () => broadcastRefresh());
    });
  }
});