const DOCK_FOLDER_NAME = "Vertical-bookmark-list";

async function getOrCreateDockFolder() {
  const tree = await browser.bookmarks.getTree();
  let dockFolder = findFolder(tree, DOCK_FOLDER_NAME);
  
  if (!dockFolder) {
    const parent = tree[0].children.find(c => c.id === '2') || tree[0]; 
    dockFolder = await browser.bookmarks.create({
      parentId: parent.id,
      title: DOCK_FOLDER_NAME
    });
  }
  return dockFolder;
}

async function getDockBookmarks() {
  const dockFolder = await getOrCreateDockFolder();
  const children = await browser.bookmarks.getChildren(dockFolder.id);
  
  const syncStorage = await browser.storage.sync.get(['customIcons', 'settingsIcon', 'showSettings']);
  const localStorage = await browser.storage.local.get(['faviconCache']);
  
  const customIcons = syncStorage.customIcons || {};
  const faviconCache = localStorage.faviconCache || {};
  
  const settingsIcon = (syncStorage.settingsIcon && syncStorage.settingsIcon.trim() !== '') 
    ? syncStorage.settingsIcon 
    : browser.runtime.getURL("gears.png");

  const itemsToCache = [];

  const processNode = async (bm) => {
    let iconUrl = '';
    
    if (customIcons[bm.id]) {
      iconUrl = customIcons[bm.id];
    } else if (faviconCache[bm.id]) {
      iconUrl = faviconCache[bm.id];
    } else if (bm.url) {
      if (!bm.url.startsWith('data:')) {
        try {
            const urlObj = new URL(bm.url);
            iconUrl = `https://www.google.com/s2/favicons?domain=${urlObj.hostname}&sz=64`;
            itemsToCache.push({ id: bm.id, url: iconUrl });
        } catch(e) { iconUrl = ""; }
      } else {
        iconUrl = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzQ0Y2NmZiI+PHBhdGggZD0iTTEwIDRINmMtMS4xIDAtMiAuOS0yIDJ2MTJjMCAxLjEuOSAyIDIgMmgxMmMxLjEgMCAyLS45IDItMlY4YzAtMS4xLS45LTItMi0yaC04bC0yLTJ6Ii8+PC9zdmc+";
      }
    } else {
      iconUrl = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzQ0Y2NmZiI+PHBhdGggZD0iTTEwIDRINmMtMS4xIDAtMiAuOS0yIDJ2MTJjMCAxLjEuOSAyIDIgMmgxMmMxLjEgMCAyLS45IDItMlY4YzAtMS4xLS45LTItMi0yaC04bC0yLTJ6Ii8+PC9zdmc+"; 
    }

    const item = { 
      id: bm.id, 
      title: bm.title, 
      url: bm.url, 
      iconUrl: iconUrl,
      index: bm.index,
      parentId: bm.parentId
    };

    if (!bm.url) {
      const subChildren = await browser.bookmarks.getChildren(bm.id);
      item.children = await Promise.all(subChildren.map(child => processNode(child)));
    }

    return item;
  };

  const bookmarks = await Promise.all(children.map(processNode));

  if (itemsToCache.length > 0) {
    cacheMissingIcons(itemsToCache);
  }

  if (syncStorage.showSettings !== false) {
    bookmarks.push({ title: "-", id: "spacer_settings" });
    bookmarks.push({
      id: "dock_settings_item",
      title: "Settings",
      url: "#settings",
      iconUrl: settingsIcon
    });
  }

  return bookmarks;
}

async function cacheMissingIcons(items) {
  const storage = await browser.storage.local.get(['faviconCache']);
  const cache = storage.faviconCache || {};

  for (const item of items) {
    try {
      const response = await fetch(item.url);
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        cache[item.id] = reader.result;
        browser.storage.local.set({ faviconCache: cache });
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.log(`Failed to cache icon for ${item.id}`, err);
    }
  }
}

function findFolder(nodes, name) {
  for (const node of nodes) {
    if (node.title === name && !node.url) return node;
    if (node.children) {
      const found = findFolder(node.children, name);
      if (found) return found;
    }
  }
  return null;
}

function broadcastRefresh() {
  getDockBookmarks().then(bookmarks => {
    browser.tabs.query({active: true, currentWindow: true}).then(tabs => {
      if (tabs[0]?.id) {
        browser.tabs.sendMessage(tabs[0].id, { action: "refresh_dock", data: bookmarks })
          .catch(() => {}); 
      }
    });
  });
}

browser.commands.onCommand.addListener(async (command) => {
  if (command === "toggle_dock") {
    const bookmarks = await getDockBookmarks();
    const tabs = await browser.tabs.query({active: true, currentWindow: true});
    if (tabs[0]?.id) {
      browser.tabs.sendMessage(tabs[0].id, { action: "toggle_dock", data: bookmarks });
    }
  }
});

// FIREFOX: onMessage expects a Promise return for async responses
browser.runtime.onMessage.addListener((request, sender) => {
  if (request.action === "get_bookmarks_for_mouse") {
    return getDockBookmarks().then(bookmarks => {
      return { data: bookmarks };
    });
  }
  
  if (request.action === "request_refresh") {
    broadcastRefresh();
  }
  
  if (request.action === "add_current_tab") {
    browser.tabs.query({active: true, currentWindow: true}).then(async (tabs) => {
        const tab = tabs[0];
        if (tab && tab.url) {
            const dockFolder = await getOrCreateDockFolder();
            await browser.bookmarks.create({
                parentId: dockFolder.id,
                title: tab.title,
                url: tab.url
            });
            broadcastRefresh();
        }
    });
  }

  if (request.action === "open_settings") { browser.runtime.openOptionsPage(); }
  if (request.action === "open_new_window") { browser.windows.create({ url: request.url }); }
  if (request.action === "open_incognito") { browser.windows.create({ url: request.url, incognito: true }); }
  
  if (request.action === "rename_bookmark") {
    browser.bookmarks.update(request.id, { title: request.title }).then(() => broadcastRefresh());
  }
  if (request.action === "delete_bookmark") {
    browser.bookmarks.remove(request.id).then(() => broadcastRefresh());
  }
  if (request.action === "update_icon") {
    browser.storage.sync.get(['customIcons']).then((result) => {
      const icons = result.customIcons || {};
      if (request.url) { icons[request.id] = request.url; } 
      else { delete icons[request.id]; }
      browser.storage.sync.set({ customIcons: icons }).then(() => broadcastRefresh());
    });
  }
  
  return false; 
});